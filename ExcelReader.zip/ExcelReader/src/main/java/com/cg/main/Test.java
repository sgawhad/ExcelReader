package com.cg.main;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.cg.stepDefinition.CommonStepDefinition;

public class Test {
	public static void main(String[] args) {

		try {
			CommonStepDefinition obj = new CommonStepDefinition();

			obj.caseNo();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
