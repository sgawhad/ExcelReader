package com.cg.helper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelReader {
	public static final String SAMPLE_XLSX_FILE_PATH = "C:/Users/SUSHEN916/Desktop/InputData.xlsx";

	Map<Integer, List<String>> data = new HashMap<Integer, List<String>>();
	public int rowNo = 1;

	public static void main(String[] args) throws IOException, InvalidFormatException {
		ExcelReader reader = new ExcelReader();

		System.out.println(reader.reader());
		System.out.println(reader.rowNo);
////		// 1. You can obtain a rowIterator and columnIterator and iterate over them
////		System.out.println("\n\nIterating over Rows and Columns using Iterator\n");
//
////		// 2. Or you can use a for-each loop to iterate over the rows and columns
////		System.out.println("\n\nIterating over Rows and Columns using for-each loop\n");
////		for (Row row : sheet) {
////			for (Cell cell : row) {
////				String cellValue = dataFormatter.formatCellValue(cell);
////				System.out.print(cellValue + "\t");
////			}
////			System.out.println();
////		}
////
////		// 3. Or you can use Java 8 forEach loop with lambda
////		System.out.println("\n\nIterating over Rows and Columns using Java 8 forEach with lambda\n");
////		sheet.forEach(row -> {
////			row.forEach(cell -> {
////				String cellValue = dataFormatter.formatCellValue(cell);
////				System.out.print(cellValue + "\t");
////			});
////			System.out.println();
////		});
////
////		// Closing the workbook
////		workbook.close();
	}

	public Map<Integer, List<String>> reader() throws InvalidFormatException, IOException {
		Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));

		Sheet sheet = workbook.getSheetAt(0);

		DataFormatter dataFormatter = new DataFormatter();
		Iterator<Row> rowIterator = sheet.rowIterator();
		Row row = rowIterator.next(); // skip heaaders
		while (rowIterator.hasNext()) {
			row = rowIterator.next();

			// Now let's iterate over the columns of the current row
			Iterator<Cell> cellIterator = row.cellIterator();
			List<String> rows = new ArrayList<String>();
			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				String cellValue = dataFormatter.formatCellValue(cell);
				rows.add(cellValue);
//				System.out.print(cellValue );

			}
//			System.out.println(rows);
//			System.out.println();
			data.put(rowNo, rows);
			rowNo++;
		}

		return data;

	}

}