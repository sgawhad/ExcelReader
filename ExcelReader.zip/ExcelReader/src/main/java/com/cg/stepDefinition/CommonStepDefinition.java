package com.cg.stepDefinition;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.cg.helper.ExcelReader;

public class CommonStepDefinition {

	public static Map<Integer, List<String>> data;
	ExcelReader reader;
	String business;
	String documentCategory;
	String documentType;
	String document;
	String effectiveDate;
	String manager;
	String product;
	String keywords;
	String subject;

	public CommonStepDefinition() throws InvalidFormatException, IOException {
		reader = new ExcelReader();
		data = reader.reader();
	}

	public void I_select_Business(String business) {

	}

	public void caseNo() throws InvalidFormatException, IOException {
		for (Integer caseNo : data.keySet()) {

//			List<String> testData = getTestData(caseNo);

			business = getBusiness(caseNo);
			documentCategory = getDocumentCategory(caseNo);
			documentType = getDocumentType(caseNo);
			document = getDocument(caseNo);
			manager = getManager(caseNo);
			effectiveDate = getEffectiveDate(caseNo);
			product = getProduct(caseNo);
			keywords = getKeywords(caseNo);
			subject = getSubject(caseNo);
			System.out.println(caseNo + "\t" + documentType);

			getXpath(documentType);

		}

	}

	public void getXpath(String key) throws IOException {
		InputStream input = new FileInputStream(
				"C:/Users/SUSHEN916/eclipse-workspace/ExcelReader/src/main/resources/repo.properties");

		Properties prop = new Properties();

		// load a properties file
		prop.load(input);

		System.out.println(prop.get(key));
	}

//	public List<String> selectBusiness() throws InvalidFormatException, IOException {
//		List<String> testData = null;
//		for (int caseNo = 0; caseNo < reader.rowNo; caseNo++) {
//			testData = getTestData(caseNo);
//		}
//		return testData;
//	}

	public List<String> getTestData(int caseNo) throws InvalidFormatException, IOException {

		List<String> testData = data.get(caseNo);

		return testData;
	}

	public String getBusiness(int caseNo) throws InvalidFormatException, IOException {

		return getTestData(caseNo).get(1);
	}

	public String getDocumentCategory(int caseNo) throws InvalidFormatException, IOException {
		return getTestData(caseNo).get(2);

	}

	public String getDocumentType(int caseNo) throws InvalidFormatException, IOException {
		return getTestData(caseNo).get(3);
	}

	public String getDocument(int caseNo) throws InvalidFormatException, IOException {
		return getTestData(caseNo).get(4);
	}

	public String getEffectiveDate(int caseNo) throws InvalidFormatException, IOException {
		return getTestData(caseNo).get(5);
	}

	public String getManager(int caseNo) throws InvalidFormatException, IOException {
		return getTestData(caseNo).get(6);
	}

	public String getProduct(int caseNo) throws InvalidFormatException, IOException {
//		return getTestData(caseNo).get(7);
		return "";
	}

	public String getKeywords(int caseNo) throws InvalidFormatException, IOException {
//		return getTestData(caseNo).get(8);
		return "";
	}

	public String getSubject(int caseNo) throws InvalidFormatException, IOException {
//		return getTestData(caseNo).get(9);
		return "";
	}
}
